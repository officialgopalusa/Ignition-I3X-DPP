"""Read-only client for the standalone Ignition DPP module."""

from java.net import URI, URLEncoder
from java.time import Instant
import math
import re


PROJECT_PATH = "/data/perspective/client/Ignition_DPP_POC"


class DppApiError(Exception):
	pass


def toNative(value):
	return system.util.jsonDecode(system.util.jsonEncode(value))


def _moduleJson(label, function, *arguments):
	try:
		return toNative(system.util.jsonDecode(str(function(*arguments))))
	except Exception, error:
		raise DppApiError("%s failed: %s" % (label, error))


def readInfo():
	return _moduleJson("DPP module info", system.dpp.readInfoJson)


def readAssets():
	payload = _moduleJson("DPP asset discovery", system.dpp.readAssetsJson)
	if not payload.get("success"):
		raise DppApiError("DPP asset discovery did not return success.")
	return payload.get("result") or []


def readPassport(assetElementId):
	if not assetElementId:
		raise DppApiError("Select a DPP-ready asset.")
	return _moduleJson("DPP passport read", system.dpp.readPassportJson, str(assetElementId))


def buildPassportUrl(gatewayAddress, assetElementId):
	base = str(gatewayAddress or "").strip().rstrip("/")
	if not base:
		base = "http://localhost:8088"
	elif not (base.startswith("http://") or base.startswith("https://")):
		base = "http://" + base
	encoded = URLEncoder.encode(str(assetElementId or ""), "UTF-8")
	return base + PROJECT_PATH + "?asset=" + encoded


def _httpUri(value):
	text = str(value or "")
	if not text or re.search(r"[\x00-\x20\x7f\\]", text):
		return None
	try:
		uri = URI(text)
		if str(uri.getScheme() or "").lower() not in ("http", "https") or not uri.getHost() or uri.getUserInfo() is not None:
			return None
		return uri
	except Exception:
		return None


def documentOpenUrl(recordElementId, records, gatewayAddress):
	# Stale selections never open another asset's document; only valid current records qualify.
	for record in records or []:
		if str(record.get("recordElementId") or "") != str(recordElementId or "") or not recordElementId or not record.get("valid"):
			continue
		url = str(record.get("url") or "")
		uri = _httpUri(url)
		if uri is None:
			return ""
		if str(uri.getPath()) == "/data/com.gopal.ignition.dpp/v1/documents":
			query = str(uri.getRawQuery() or "")
			if not re.match(r"^documentId=[a-z0-9][a-z0-9-]{0,159}$", query) or uri.getFragment() is not None:
				return ""
			if str(uri.getHost()).lower() in ("localhost", "127.0.0.1", "[::1]", "::1"):
				base = buildPassportUrl(gatewayAddress, "").split(PROJECT_PATH, 1)[0]
				baseUri = _httpUri(base)
				if baseUri is None or str(baseUri.getPath() or "") not in ("", "/") or baseUri.getRawQuery() is not None or baseUri.getFragment() is not None:
					return ""
				return base.rstrip("/") + str(uri.getPath()) + "?" + query
		return url
	return ""


def _documentOptions(records, gatewayAddress):
	return [{"label": str(record.get("title") or record.get("recordName") or "Document"), "value": str(record.get("recordElementId"))}
		for record in records or [] if documentOpenUrl(record.get("recordElementId"), records, gatewayAddress)]


def _preferredAsset(assets, requestedId):
	requested = str(requestedId or "")
	for asset in assets:
		if str(asset.get("assetElementId") or "") == requested:
			return asset
	if requested:
		raise DppApiError("The selected asset is no longer available. Choose another asset.")
	for asset in assets:
		if asset.get("dppReady"):
			return asset
	return assets[0] if assets else None


def _assetOptions(assets):
	options = []
	for asset in assets:
		label = "%s - %s" % (asset.get("displayName") or "Asset", asset.get("path") or "")
		if not asset.get("dppReady"):
			label += " - Metadata incomplete"
		options.append({"label": label, "value": asset.get("assetElementId")})
	return options


def _pretty(value):
	try:
		return system.util.jsonEncode(value, 2)
	except Exception:
		return system.util.jsonEncode(value)


def _formatValue(value):
	if value is None:
		return "Unavailable"
	if isinstance(value, bool):
		return "True" if value else "False"
	try:
		number = float(value)
		if number == int(number):
			return str(int(number))
		return ("%.2f" % number).rstrip("0").rstrip(".")
	except Exception:
		return str(value)


def _historyPoints(history):
	# A sparkline cannot reliably express quality gaps: show only the latest
	# contiguous run of valid numeric samples, never bridge a Bad/missing point.
	points = []
	for point in history or []:
		value = point.get("value")
		if point.get("quality") != "Good" or value is None or isinstance(value, bool):
			points = []
			continue
		try:
			y = float(value)
			if math.isnan(y) or math.isinf(y):
				raise ValueError("Non-finite sample")
			x = Instant.parse(str(point.get("timestamp") or "")).toEpochMilli()
			if points and x <= points[-1]["x"]:
				continue
			points.append({"x": x, "y": y})
		except Exception:
			points = []
	return points


def _formatOperationalField(field):
	result = dict(field or {})
	quality = str(result.get("quality") or "Unknown")
	result["formattedValue"] = _formatValue(result.get("value"))
	result["unitOfMeasure"] = str(result.get("unitOfMeasure") or "")
	result["unitLabel"] = result["unitOfMeasure"] or "Not configured"
	result["available"] = bool(result.get("i3xElementId"))
	result["qualityColor"] = "#087f5b" if quality == "Good" else "#b42318"
	result["qualityLabel"] = quality + " quality"
	result["historyPoints"] = _historyPoints(result.get("history") or [])
	return result


def _formatTechnicalField(field):
	result = _formatOperationalField(field)
	result["groupLabel"] = str(result.get("groupPath") or "General")
	return result


def _formatDocumentRecord(record):
	result = dict(record or {})
	valid = bool(result.get("valid"))
	issues = [str(item) for item in (result.get("validationIssues") or [])]
	result["statusLabel"] = "Ready" if valid else "Review"
	result["validationLabel"] = "Valid source record" if valid else "; ".join(issues)
	result["integrityLabel"] = "SHA-256 supplied" if result.get("checksumSha256") else "Not supplied"
	for field in ("documentType", "title", "version", "documentNumber", "issuerName", "issueDate", "validUntil", "language", "url", "lastUpdate", "recordElementId"):
		result[field] = str(result.get(field) or "")
	return result


def _emptyFeaturedSignal():
	return {
		"available": False,
		"displayName": "No live signal",
		"formattedValue": "-",
		"unitOfMeasure": "",
		"unitLabel": "Not configured",
		"qualityColor": "#815700",
		"quality": "NotMapped",
		"qualityLabel": "Not mapped",
		"timestamp": "",
		"historyPoints": []
	}


def loadDashboardRequest(request):
	parts = request.split("|", 4)
	selectedAssetId = parts[1] if len(parts) > 1 else ""
	urlAssetId = parts[3] if len(parts) > 3 else ""
	gatewayAddress = parts[4] if len(parts) > 4 else ""
	assetId = selectedAssetId or urlAssetId
	try:
		return loadDashboard(assetId, gatewayAddress)
	except Exception, error:
		return errorState(error, assetId)


def loadDashboard(selectedAssetId="", gatewayAddress=""):
	info = readInfo()
	assets = readAssets()
	try:
		asset = _preferredAsset(assets, selectedAssetId)
		if asset is None:
			raise DppApiError("No I3X assets with Asset Information were discovered.")
		passport = readPassport(asset.get("assetElementId"))
	except Exception, error:
		return errorState(error, selectedAssetId, assets)
	fields = ((passport.get("source") or {}).get("fields") or [])
	technical = passport.get("technicalData") or {}
	technicalFields = [_formatTechnicalField(field) for field in (technical.get("fields") or [])]
	operational = passport.get("operationalData") or {}
	operationalFields = [_formatOperationalField(field) for field in (operational.get("fields") or [])]
	documents = passport.get("documentsAndCompliance") or {}
	documentRecords = [_formatDocumentRecord(record) for record in (documents.get("documents") or [])]
	featuredSignals = [field for field in operationalFields if field.get("featured")][:4]
	while len(featuredSignals) < 4:
		featuredSignals.append(_emptyFeaturedSignal())
	goodCount = len([field for field in fields if str(field.get("quality") or "") == "Good"])
	technicalGoodCount = len([field for field in technicalFields if str(field.get("quality") or "") == "Good"])
	operationalGoodCount = len([field for field in operationalFields if str(field.get("quality") or "") == "Good"])
	documentValidCount = len([record for record in documentRecords if record.get("valid")])
	documentInvalidCount = len(documentRecords) - documentValidCount
	readyCount = len([item for item in assets if item.get("dppReady")])
	profiles = passport.get("contentSpecificationIds") or []
	version = str(info.get("serverVersion") or "unknown")
	passportUrl = buildPassportUrl(gatewayAddress, asset.get("assetElementId"))
	return {
		"connected": True,
		"message": "Read-only POC. Identity, technical specifications, operational signals, and optional document references are live from I3X; this screen writes nothing and makes no compliance determination.",
		"versionLabel": "DPP module %s - UI 0.12.0" % version,
		"readLabel": "Last successful read: %s" % Instant.now().toString(),
		"unitSummary": "%s / %s signal units configured" % (len([field for field in operationalFields if field.get("unitOfMeasure")]), len(operationalFields)),
		"assetOptions": _assetOptions(assets),
		"assetCount": len(assets),
		"readyCount": readyCount,
		"selectedAssetId": asset.get("assetElementId"),
		"passportUrl": passportUrl,
		"selectedAsset": asset,
		"readinessLabel": "%s of %s discovered assets DPP-ready" % (readyCount, len(assets)),
		"qualitySummary": "%s / %s fields Good" % (goodCount, len(fields)),
		"operationalQualitySummary": ("%s / %s signals Good" % (operationalGoodCount, len(operationalFields))) if operationalFields else "No direct operational signals",
		"operationalLastUpdate": str(operational.get("lastUpdate") or "No signal timestamp"),
		"operationalFields": operationalFields,
		"technicalQualitySummary": ("%s / %s specifications Good" % (technicalGoodCount, len(technicalFields))) if technicalFields else "Technical data not configured",
		"technicalUnitSummary": "%s / %s technical units configured" % (len([field for field in technicalFields if field.get("unitOfMeasure")]), len(technicalFields)),
		"technicalFields": technicalFields,
		"documentSummary": ("%s / %s document records ready" % (documentValidCount, len(documentRecords))) if documents.get("configured") else "Documents not configured (optional)",
		"documentValidationSummary": ("All records valid" if documentRecords and not documentInvalidCount else ("%s record(s) need review" % documentInvalidCount if documentInvalidCount else "No document records")),
		"documentRecords": documentRecords,
		"documentOptions": _documentOptions(documentRecords, gatewayAddress),
		"featuredSignal0": featuredSignals[0],
		"featuredSignal1": featuredSignals[1],
		"featuredSignal2": featuredSignals[2],
		"featuredSignal3": featuredSignals[3],
		"schemaLabel": "POC 0.3.0",
		"contentProfiles": " | ".join([str(item) for item in profiles]),
		"rawJson": _pretty(passport),
		"passport": passport
	}


def errorState(error, selectedAssetId="", assets=None):
	message = "DPP frontend could not load: %s" % error
	return {
		"connected": False,
		"message": message,
		"versionLabel": "DPP UI 0.12.0",
		"readLabel": "Read failed - displayed data cleared",
		"unitSummary": "Units: source unavailable",
		"assetOptions": _assetOptions(assets or []),
		"assetCount": 0,
		"readyCount": 0,
		"selectedAssetId": selectedAssetId,
		"passportUrl": "",
		"selectedAsset": {"displayName": "Unavailable", "path": "", "dppReady": False},
		"readinessLabel": "DPP module unavailable",
		"qualitySummary": "I3X quality unavailable",
		"operationalQualitySummary": "Live signals unavailable",
		"operationalLastUpdate": "",
		"operationalFields": [],
		"technicalQualitySummary": "Technical data unavailable",
		"technicalUnitSummary": "Technical units unavailable",
		"technicalFields": [],
		"documentSummary": "Documents unavailable",
		"documentValidationSummary": "Source unavailable",
		"documentRecords": [],
		"documentOptions": [],
		"featuredSignal0": _emptyFeaturedSignal(),
		"featuredSignal1": _emptyFeaturedSignal(),
		"featuredSignal2": _emptyFeaturedSignal(),
		"featuredSignal3": _emptyFeaturedSignal(),
		"schemaLabel": "POC 0.3.0",
		"contentProfiles": "",
		"rawJson": _pretty({"error": message}),
		"passport": {
			"digitalProductPassportId": "",
			"uniqueProductIdentifier": "",
			"granularity": "",
			"dppSchemaVersion": "",
			"dppStatus": "Unavailable",
			"lastUpdate": "",
			"economicOperatorId": "",
			"facilityId": "",
			"contentSpecificationIds": [],
			"productInformation": {
				"productName": "DPP data unavailable",
				"manufacturerName": "",
				"manufacturerProductType": "",
				"manufacturerProductDesignation": "",
				"serialNumber": "",
				"dateOfManufacture": ""
			},
			"technicalData": {"fieldCount": 0, "goodFieldCount": 0, "unitConfiguredFieldCount": 0, "fields": []},
			"operationalData": {"fieldCount": 0, "goodFieldCount": 0, "featuredFieldCount": 0, "fields": []},
			"documentsAndCompliance": {"configured": False, "recordCount": 0, "validDocumentCount": 0, "invalidRecordCount": 0, "documents": []},
			"source": {
				"protocol": "I3X",
				"sourceModuleId": "",
				"i3xBaseUrl": "",
				"assetElementId": "",
				"assetPath": "",
				"assetInformationElementId": "",
				"documentsAndComplianceElementId": "",
				"fields": []
			}
		}
	}
