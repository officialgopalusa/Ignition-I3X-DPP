"""Gateway-safe client for the I3X Tag Server configuration API.

The module owns validation and persistence.  Perspective only edits a copy of
the configuration and sends the complete document back with its revision.
"""

BASE_URL = (
	"http://localhost:8088/data/"
	"com.gopal.ignition.i3xdpp/config/v1/model"
)

JSON_HEADERS = {
	"Accept": "application/json",
	"Content-Type": "application/json"
}


class ConfigurationApiError(Exception):
	pass


def toNative(value):
	"""Convert Perspective documents/maps into ordinary Python containers."""
	return system.util.jsonDecode(system.util.jsonEncode(value))


def _errorMessage(response, payload):
	detail = (payload or {}).get("responseDetail") or {}
	message = detail.get("detail")
	if message:
		return message
	return "Configuration API returned HTTP %s" % response.statusCode


def _request(method, suffix="", body=None):
	url = BASE_URL + suffix
	method = method.upper()
	if method == "GET":
		response = system.net.httpClient.get(url, headers=JSON_HEADERS)
	elif method == "POST":
		response = system.net.httpClient.post(
			url,
			data=body,
			headers=JSON_HEADERS
		)
	elif method == "PUT":
		response = system.net.httpClient.put(
			url,
			data=body,
			headers=JSON_HEADERS
		)
	else:
		raise ConfigurationApiError("Unsupported HTTP method: %s" % method)

	try:
		payload = response.json
	except Exception:
		payload = {}

	if not response.good:
		raise ConfigurationApiError(_errorMessage(response, payload))
	if not payload or not payload.get("success"):
		raise ConfigurationApiError(_errorMessage(response, payload))
	return toNative(payload)


def _requireCurrent(configuration):
	if str(configuration.get("configurationVersion") or "") != "2.0":
		raise ConfigurationApiError("This editor requires I3X Tag Server 0.1.48 or later (configuration 2.0). Install the matching module, then Refresh.")


def readModel():
	payload = _request("GET")
	_requireCurrent(payload["result"]["configuration"])
	return payload


def validateModel(configuration):
	return _request(
		"POST",
		"/validate",
		{"configuration": toNative(configuration)}
	)


def saveModel(expectedRevision, configuration):
	_requireCurrent(toNative(configuration))
	return _request(
		"PUT",
		body={
			"expectedRevision": int(expectedRevision),
			"configuration": toNative(configuration)
		}
	)


def resetModel(expectedRevision):
	return _request(
		"POST",
		"/reset",
		{"expectedRevision": int(expectedRevision)}
	)


NUMERIC_TAG_TYPES = (
	"Int1", "Int2", "Int4", "Int8", "Float4", "Float8",
	"Byte", "Short", "Integer", "Long", "Float", "Double",
	"BigInteger", "BigDecimal"
)

INTEGER_TAG_TYPES = (
	"Int1", "Int2", "Int4", "Int8", "Byte", "Short",
	"Integer", "Long", "BigInteger"
)

MAX_TAG_BINDINGS = 1000


def fullyQualifiedTagPath(path):
	"""Normalize a Tag Browse Tree selection to Ignition's [provider]path form."""
	text = "" if path is None else str(path).strip()
	if not text or text.startswith("["):
		return text
	parts = text.split("/", 1)
	if len(parts) == 1:
		return "[%s]" % parts[0]
	return "[%s]%s" % (parts[0], parts[1])


def _browseTagMetadata(tagPath):
	"""Find one tag's browse metadata when sparse configuration omits datatype."""
	path = fullyQualifiedTagPath(tagPath)
	if not path:
		return {}
	providerEnd = path.find("]")
	body = path[providerEnd + 1:].strip("/") if providerEnd >= 0 else path
	if "/" in body:
		parentPath = path.rsplit("/", 1)[0]
	elif providerEnd >= 0:
		parentPath = path[:providerEnd + 1]
	else:
		parentPath = ""
	try:
		results = system.tag.browse(parentPath, {"recursive": False}).getResults()
	except Exception:
		return {}
	for result in results:
		fullPath = fullyQualifiedTagPath(result.get("fullPath"))
		if fullPath == path:
			return {
				"tagType": str(result.get("tagType") or ""),
				"dataType": str(result.get("dataType") or "")
			}
	return {}


def inspectTag(path, expectedKind):
	"""Return selection metadata and reject folders or incompatible data types."""
	tagPath = fullyQualifiedTagPath(path)
	if not tagPath:
		return {"valid": False, "message": "Select a tag first."}

	try:
		configurations = system.tag.getConfiguration(tagPath, False)
	except Exception, e:
		return {
			"valid": False,
			"tagPath": tagPath,
			"message": "The selected path could not be inspected: %s" % e
		}

	if configurations is None or len(configurations) == 0:
		return {
			"valid": False,
			"tagPath": tagPath,
			"message": "Select an atomic Ignition tag, not a provider or folder."
		}

	configuration = configurations[0]
	tagType = str(configuration.get("tagType", ""))
	dataType = str(configuration.get("dataType", ""))
	if not dataType:
		metadata = _browseTagMetadata(tagPath)
		dataType = metadata.get("dataType") or dataType
		tagType = metadata.get("tagType") or tagType
	if tagType in ("Folder", "UdtInstance", "UdtType", "Provider") or not dataType:
		return {
			"valid": False,
			"tagPath": tagPath,
			"tagType": tagType,
			"dataType": dataType,
			"message": "Select an atomic value tag, not %s." % (tagType or "this node")
		}

	expectedKind = str(expectedKind or "").lower()
	if expectedKind == "numeric":
		compatible = dataType in NUMERIC_TAG_TYPES
		expectedDescription = "a numeric tag"
	elif expectedKind == "string":
		compatible = dataType == "String"
		expectedDescription = "a String tag"
	else:
		compatible = True
		expectedDescription = "a compatible tag"

	if not compatible:
		return {
			"valid": False,
			"tagPath": tagPath,
			"tagType": tagType,
			"dataType": dataType,
			"message": "This binding requires %s; the selected tag is %s." % (
				expectedDescription,
				dataType or "untyped"
			)
		}

	quality = "Unknown"
	valuePreview = ""
	try:
		qualifiedValue = system.tag.readBlocking([tagPath])[0]
		quality = str(qualifiedValue.quality)
		valuePreview = "" if qualifiedValue.value is None else str(qualifiedValue.value)
	except Exception:
		# A valid configuration path may still be temporarily unreadable. The
		# existing Save/Activate and I3X verification flow remains authoritative.
		pass

	return {
		"valid": True,
		"tagPath": tagPath,
		"tagType": tagType,
		"dataType": dataType,
		"quality": quality,
		"valuePreview": valuePreview,
		"message": "Compatible %s tag selected (%s quality)." % (dataType, quality)
	}


def xsdTypeForIgnition(dataType):
	"""Map common atomic Ignition types into the POC's JSON/XSD scalar set."""
	name = str(dataType or "")
	if name in INTEGER_TAG_TYPES:
		return "xsd:integer"
	if name in NUMERIC_TAG_TYPES:
		return "xsd:decimal"
	if name == "Boolean":
		return "xsd:boolean"
	if name in ("Date", "DateTime"):
		return "xsd:dateTime"
	if name in ("String", "Text"):
		return "xsd:string"
	return None


def _words(value):
	text = str(value or "")
	result = []
	current = ""
	for character in text:
		if character.isalnum():
			current += character
		elif current:
			result.append(current)
			current = ""
	if current:
		result.append(current)
	return result


def suggestedBindingKey(tagPath, existingKeys=None):
	"""Create a stable lower-camel I3X property name from the selected tag."""
	path = fullyQualifiedTagPath(tagPath)
	leaf = path.rsplit("/", 1)[-1]
	parts = _words(leaf)
	if not parts:
		base = "tagValue"
	else:
		base = parts[0][:1].lower() + parts[0][1:]
		for part in parts[1:]:
			base += part[:1].upper() + part[1:]
	if not base[0].isalpha():
		base = "tag" + base[:1].upper() + base[1:]
	base = base[:64]
	existing = set([str(item) for item in (existingKeys or [])])
	if base not in existing:
		return base
	index = 2
	while True:
		suffix = str(index)
		candidate = base[:64 - len(suffix)] + suffix
		if candidate not in existing:
			return candidate
		index += 1


def bindingCandidate(tagPath, dataType=None, existingKeys=None):
	"""Create one editable staging row for an atomic scalar Ignition tag."""
	path = fullyQualifiedTagPath(tagPath)
	if dataType is None:
		inspection = inspectTag(path, "any")
		if not inspection.get("valid"):
			return inspection
		dataType = inspection.get("dataType")
	else:
		inspection = {"valid": True, "tagPath": path, "dataType": str(dataType)}
	xsdType = xsdTypeForIgnition(dataType)
	if xsdType is None:
		return {
			"valid": False,
			"tagPath": path,
			"dataType": str(dataType or ""),
			"message": "Unsupported atomic tag datatype: %s." % (dataType or "unknown")
		}
	return {
		"valid": True,
		"fieldName": suggestedBindingKey(path, existingKeys),
		"tagPath": path,
		"ignitionDataType": str(dataType),
		"valueDataType": xsdType,
		"unitOfMeasure": "",
		"area": _areaFromPath(path),
		"message": inspection.get("message") or "Tag added to the staging list."
	}


def _areaFromPath(tagPath):
	path = fullyQualifiedTagPath(tagPath)
	body = path.split("]", 1)[-1].strip("/")
	parts = body.split("/")
	if len(parts) <= 1:
		return "Root"
	return "/".join(parts[:-1])


def additionalBindingRows(bindings):
	"""Return every user-managed tag mapping as an editable UI row."""
	native = toNative(bindings or {})
	rows = []
	for key in sorted(native.keys()):
		binding = native.get(key) or {}
		rows.append({
			"fieldName": str(key),
			"tagPath": str(binding.get("tagPath") or ""),
			"ignitionDataType": "",
			"valueDataType": str(binding.get("valueDataType") or ""),
			"unitOfMeasure": str(binding.get("unitOfMeasure") or ""),
			"area": _areaFromPath(binding.get("tagPath"))
		})
	return rows


def additionalBindingDataset(bindings):
	"""Return read-only additional mappings as a Perspective-safe Dataset."""
	headers = (
		"fieldName",
		"tagPath",
		"valueDataType",
		"unitOfMeasure",
		"area"
	)
	data = []
	for row in additionalBindingRows(bindings):
		data.append([
			row.get("fieldName") or "",
			row.get("tagPath") or "",
			row.get("valueDataType") or "",
			row.get("unitOfMeasure") or "",
			row.get("area") or ""
		])
	return system.dataset.toDataSet(headers, data)


def normalizeRowList(value):
	"""Return Perspective row data as a defensive list of dictionaries.

	Perspective document/array properties can arrive in project scripts as a
	Document adapter, an encoded JSON string, or a map with numeric keys. Button
	handlers must not iterate those values directly because doing so yields
	unicode keys instead of mapping rows.
	"""
	native = toNative(value or [])
	if isinstance(native, basestring):
		try:
			native = system.util.jsonDecode(native)
		except Exception:
			return []
	if isinstance(native, dict):
		if "fieldName" in native and "tagPath" in native:
			native = [native]
		else:
			keys = native.keys()
			if keys and all(str(key).isdigit() for key in keys):
				keys = sorted(keys, key=lambda key: int(str(key)))
				native = [native[key] for key in keys]
			else:
				return additionalBindingRows(native)
	rows = []
	for item in native or []:
		if isinstance(item, dict):
			rows.append(item)
			continue
		try:
			decoded = toNative(item)
			if isinstance(decoded, dict):
				rows.append(decoded)
		except Exception:
			pass
	return rows


def validateAdditionalRows(rows, existingBindings=None):
	"""Validate staged rows before they are merged into the model document."""
	nativeRows = normalizeRowList(rows)
	errors = []
	cleanRows = []
	keys = set()
	paths = set()
	if len(nativeRows) > MAX_TAG_BINDINGS:
		errors.append("The model supports at most %s total tag bindings." % MAX_TAG_BINDINGS)
	for index, source in enumerate(nativeRows):
		row = source or {}
		fieldName = str(row.get("fieldName") or "").strip()
		tagPath = fullyQualifiedTagPath(row.get("tagPath"))
		valueDataType = str(row.get("valueDataType") or "").strip()
		unit = str(row.get("unitOfMeasure") or "").strip()
		label = "Row %s" % (index + 1)
		if not fieldName or not fieldName[0].isalpha() or len(fieldName) > 64 \
			or any(not (character.isalnum() or character == "_") for character in fieldName):
			errors.append("%s has an invalid I3X field name." % label)
		elif fieldName in keys:
			errors.append("%s duplicates I3X field name %s." % (label, fieldName))
		else:
			keys.add(fieldName)
		if not tagPath or not tagPath.startswith("[") or "]" not in tagPath:
			errors.append("%s does not contain a fully qualified tag path." % label)
		elif tagPath in paths:
			errors.append("%s duplicates tag path %s." % (label, tagPath))
		else:
			paths.add(tagPath)
		if valueDataType not in (
			"xsd:decimal", "xsd:integer", "xsd:boolean", "xsd:string", "xsd:dateTime"
		):
			errors.append("%s has unsupported datatype %s." % (label, valueDataType))
		if valueDataType in ("xsd:boolean", "xsd:string", "xsd:dateTime") and unit:
			errors.append("%s must not define a unit for %s." % (label, valueDataType))
		cleanRows.append({
			"fieldName": fieldName,
			"tagPath": tagPath,
			"ignitionDataType": str(row.get("ignitionDataType") or ""),
			"valueDataType": valueDataType,
			"unitOfMeasure": unit,
			"area": _areaFromPath(tagPath)
		})
	return {"valid": len(errors) == 0, "errors": errors, "rows": cleanRows}


def mergeAdditionalBindings(bindings, rows):
	"""Replace the editable mapping set; an empty staging list removes all mappings."""
	result = {}
	validation = validateAdditionalRows(rows)
	if not validation.get("valid"):
		raise ConfigurationApiError("; ".join(validation.get("errors") or []))
	for row in validation.get("rows") or []:
		binding = {
			"tagPath": row.get("tagPath"),
			"valueDataType": row.get("valueDataType")
		}
		unit = row.get("unitOfMeasure")
		if unit:
			binding["unitOfMeasure"] = unit
		result[row.get("fieldName")] = binding
	return result


def browseAtomicTags(path, existingKeys=None, existingPaths=None, limit=MAX_TAG_BINDINGS):
	"""Recursively stage compatible scalar tags under a selected folder/provider."""
	root = fullyQualifiedTagPath(path)
	try:
		results = system.tag.browse(root, {"recursive": True}).getResults()
	except Exception, e:
		return {"valid": False, "rows": [], "message": "Folder browse failed: %s" % e}
	existingKeys = list(existingKeys or [])
	existingPaths = set([str(item) for item in (existingPaths or [])])
	rows = []
	skipped = 0
	for result in results:
		if len(rows) >= int(limit):
			break
		tagType = str(result.get("tagType") or "")
		dataType = str(result.get("dataType") or "")
		fullPath = fullyQualifiedTagPath(result.get("fullPath"))
		if tagType in ("Folder", "UdtInstance", "UdtType", "Provider"):
			continue
		if not fullPath or fullPath in existingPaths:
			skipped += 1
			continue
		candidate = bindingCandidate(fullPath, dataType, existingKeys)
		if not candidate.get("valid"):
			skipped += 1
			continue
		rows.append(candidate)
		existingKeys.append(candidate.get("fieldName"))
		existingPaths.add(fullPath)
	return {
		"valid": True,
		"rows": rows,
		"message": "Added %s compatible value tags; skipped %s duplicates or unsupported tags." % (
			len(rows), skipped
		)
	}
